/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

package com.trolltech.qtcppproject.editors;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.ui.IEditorInput;
import org.eclipse.ui.IEditorSite;
import org.eclipse.ui.PartInitException;
import org.eclipse.ui.forms.editor.FormEditor;

import com.trolltech.qtcppcommon.editors.EditorInputWatcher;
import com.trolltech.qtcppcommon.editors.IQtEditor;
import com.trolltech.qtcppproject.pages.ProCommonPage;
import com.trolltech.qtcppproject.pages.ProSourcePage;

public class ProEditor extends FormEditor implements IQtEditor {
	public static String ID = "com.trolltech.qtcppproject.editors.ProEditor";
	
	private ProSourcePage sourceEditorPage = null;
	private ProCommonPage visualEditorPage = null;
	private EditorInputWatcher listener;
	
	public ProEditor() {
		super();
	}
	
	public void init(IEditorSite site, IEditorInput input) throws PartInitException {
		super.init(site, input);
		listener = new EditorInputWatcher(this);
	}

	public void doSave(IProgressMonitor monitor)
	{
		visualEditorPage.doSave(monitor);
		listener.updateTimeStamp();
	}
	
	public void doSaveAs()
	{
	
	}
	
	public boolean isSaveAsAllowed()
	{
		return false;
	}
	
	public boolean isActionEnabled(int actId) {
		return visualEditorPage.isActionEnabled(actId);
	}
	
	public void triggerAction(int actId) {
		visualEditorPage.triggerAction(actId);
	}
	
	protected void addPages()
	{
		try {
			visualEditorPage = new ProCommonPage(this);
			addPage(visualEditorPage);
			sourceEditorPage = new ProSourcePage(this);
			addPage(sourceEditorPage, getEditorInput());
		} catch(Exception e) {
			//### show warning
		}
		
		setPartName(getEditorInput().getName());
	}
	
	public boolean isDirty() {
		return visualEditorPage.isDirty();
	}
	
	protected void pageChange(int newPageIndex) {
		if (newPageIndex == 0) {
			visualEditorPage.setFocus();
		} else if (newPageIndex == 1) {
			sourceEditorPage.getDocument().set(visualEditorPage.contents());
		}
		
		super.pageChange(newPageIndex);
	}

	public void dispose() {
		listener.dispose();
		super.dispose();
	}

	public void reload() {
		visualEditorPage.reload();
	}

	public void setFocus() {
		super.setFocus();
		if (getCurrentPage() == 0)
			visualEditorPage.setFocus();
	}
}

/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

package com.trolltech.qtcppproject.editors;

import org.eclipse.jface.text.rules.EndOfLineRule;
import org.eclipse.jface.text.rules.IPredicateRule;
import org.eclipse.jface.text.rules.MultiLineRule;
import org.eclipse.jface.text.rules.RuleBasedPartitionScanner;
import org.eclipse.jface.text.rules.Token;

import com.trolltech.qtcppproject.QtProConstants;

public class ProPartitionScanner extends RuleBasedPartitionScanner
{
	public final static String PRO_COMMENT = "__pro_comment";
	public final static String PRO_SETTINGS = "__pro_settings";
	public final static String PRO_FILES = "__pro_files";
	public final static String[] PARTITION_TYPES = 
		{PRO_COMMENT, PRO_SETTINGS, PRO_FILES};
	
	public ProPartitionScanner()
	{
		super();
		IPredicateRule[] rules = new IPredicateRule[3];
		Token comment = new Token(PRO_COMMENT);
		Token settings = new Token(PRO_SETTINGS);
		Token files = new Token(PRO_FILES);
		
		rules[0] = new MultiLineRule(QtProConstants.SETTINGS_BEGIN_TAG, 
				QtProConstants.SETTINGS_END_TAG, settings);
		rules[1] = new MultiLineRule(QtProConstants.FILES_BEGIN_TAG, 
				QtProConstants.FILES_END_TAG, files);
		rules[2] = new EndOfLineRule("#", comment);
		
		setPredicateRules(rules);
	}
}

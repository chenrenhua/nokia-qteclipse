/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

#include "resourceeditorw.h"
#include "formeditorw.h"
#include "widgetboxw.h"

#include <QResizeEvent>
#include <QtCore/QDebug>

ResourceEditorW *ResourceEditorW::m_self = 0;

ResourceEditorW::ResourceEditorW(QWidget *parent)
    : QWidget(parent), m_editor(0), m_initialized(false)
{
    if (m_self != 0)
        delete m_self;
    m_self = this;
    FormEditorW::instance()->setResourceEditor(this);
}

ResourceEditorW::~ResourceEditorW()
{
    m_self = 0;
    FormEditorW::instance()->setResourceEditor(0);

    if (m_editor != 0) {
        m_editor->hide();
        m_editor->setParent(0);
    }
}

void ResourceEditorW::initialize()
{
    if (!m_initialized) {
        m_initialized = true;
        FormEditorW::instance()->initialize();

        m_editor = QDesignerComponents::createResourceEditor(FormEditorW::instance()->formEditor(), this);
        FormEditorW::instance()->setResourceEditor(this);
    }
}

void ResourceEditorW::updateCustomWidgetLocation(const QString &path)
{
    WidgetBoxW *w = WidgetBoxW::instance();
    if (w != 0) {
        w->updateCustomWidgetLocation(path);
    }
}

ResourceEditorW *ResourceEditorW::instance()
{
    if (m_self == 0)
        m_self = new ResourceEditorW();
    m_self->initialize();

    return m_self;
}

// Only called when Qt Jambi is installed
void ResourceEditorW::updateResources(const QString &paths)
{
    if (m_editor != 0)
        QMetaObject::invokeMethod(m_editor, "updateRootDirs", Q_ARG(QString, paths));
}

bool ResourceEditorW::initializeJambiPlugins(const QString &jambiBase, const QString &jambiPluginPath,
                                             const QString &customWidgetClassPath, const QString &resourcePath, const QString &jvm)
{
    return FormEditorW::instance()->initializeJambiPlugins(jambiBase, jambiPluginPath, customWidgetClassPath, resourcePath, jvm);
}


void ResourceEditorW::resizeEvent(QResizeEvent *event)
{
    if (m_editor != 0)
        m_editor->resize(event->size());
    QWidget::resizeEvent(event);
}

QSize ResourceEditorW::minimumSize()
{
    if (m_editor != 0)
        return m_editor->minimumSize();
    else
        return QWidget::minimumSize();
}

QString ResourceEditorW::pluginFailureString() const
{
    return FormEditorW::instance()->pluginFailureString();
}


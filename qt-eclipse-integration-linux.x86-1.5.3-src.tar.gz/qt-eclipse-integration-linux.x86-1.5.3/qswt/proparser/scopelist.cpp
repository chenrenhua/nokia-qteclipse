/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

#include <QtCore/QDir>
#include <QtCore/QList>
#include <QtGui/QHeaderView>
#include <QtCore/QModelIndex>

#include "scopelist.h"
#include "proeditormodel.h"
#include "proitems.h"
#include "proeditorview.h"

using namespace Qt4ProjectManager::Internal;

ScopeList::ScopeList(QWidget *parent)
    : QTreeView(parent)
{
    header()->setVisible(false);
}

ScopeList::~ScopeList()
{
    foreach (ProEditorModel *m, m_models.keys())
        ProEditorView::releaseModel(m);
}

ProEditorModel *ScopeList::proEditorModel(const QString &fileName)
{
    ProEditorModel *value = ProEditorView::aquireModel(fileName);
    if (!value)
        return 0;
    if (m_models.contains(value)) {
        //already aquired it, so release again and return
        ProEditorView::releaseModel(value);
    } else {
        m_models.insert(value, 0);
    }
    return value;
}

void ScopeList::showModel(const QString &fileName, bool enabled)
{
    ProEditorModel *modelHandle = proEditorModel(fileName);
    if (modelHandle) {
        ProScopeFilter *mf = filter(modelHandle);
        if (mf == model())
            return;
        foreach (QString key, m_files.keys()) {
            ensureVariable(key, modelHandle);
        }
        setModel(mf);
        expandAll();
    }
    setEnabled(enabled);
}

void ScopeList::ensureVariable(const QString &variable, ProEditorModel *model)
{
    QList<QModelIndex> vars = model->findVariables(QStringList(variable));
    if (vars.isEmpty()) {
        vars = model->findBlocks();
        if (!vars.isEmpty()) {
            ProVariable *var = new ProVariable(variable.toAscii(), model->proBlock(vars[0]));
            model->insertItem(var, model->rowCount(vars[0]), vars[0]);
        }
    }
}

void ScopeList::selectFirstVariable()
{
    if (ProScopeFilter *mf = qobject_cast<ProScopeFilter *>(model())) {
        ProEditorModel *m = qobject_cast<ProEditorModel*>(mf->sourceModel());

        QStringList vars = m_files.keys();
        for (int i=0; i<vars.count(); ++i) {
            QList<QModelIndex> indexes = m->findVariables(QStringList(vars.at(i)));
            if (!indexes.isEmpty()) {
                mf->setData(mf->mapFromSource(indexes.first()),
                    QVariant((int)Qt::Checked), Qt::CheckStateRole);
            }
        }
    }
}

void ScopeList::addFile(const QString &file, const QString &var)
{
    QFileInfo info(file);
    m_files.insert(var, info);
    m_filenames << file;
}

bool ScopeList::search(const QString &fileName)
{
    bool found = false;
    ProEditorModel *m = proEditorModel(fileName);
    if (!m)
        return false;
    ProScopeFilter *mf = filter(m);

    QFileInfo profile(m->proFiles().first()->fileName());
    QList<QModelIndex> indexes = m->findVariables(m_files.keys());
    for (int i=0; i<indexes.size(); ++i) {
        QModelIndex varindex = indexes.at(i);
        for (int j=m->rowCount(varindex) - 1; j>=0; --j) {
            QModelIndex valindex = m->index(j,0,varindex);
            ProItem *item = m->proItem(valindex);
            if (!item || item->kind() != ProItem::ValueKind)
                continue;
            ProValue *val = static_cast<ProValue *>(item);
            QString absolutePathVal = QDir::toNativeSeparators(
                    profile.dir().absoluteFilePath(val->value()));
            if (m_filenames.contains(absolutePathVal)) {
                found = true;
                mf->setData(mf->mapFromSource(varindex),
                    QVariant((int)Qt::Checked), Qt::CheckStateRole);
                break;
            }
        }
    }

    return found;
}

bool ScopeList::isChanged(const QString &fileName)
{
    ProEditorModel *m = proEditorModel(fileName);
    if (!m)
        return false;
    ProScopeFilter *mf = filter(m);
    return !mf->checkedIndexes().isEmpty();
}

void ScopeList::removeFiles()
{
    QList<ProScopeFilter *> filters = m_models.values();
    // for each project file
    for (int i=0; i<filters.count(); ++i) {
        ProEditorModel *m = qobject_cast<ProEditorModel*>(filters.at(i)->sourceModel());
        QFileInfo profile(m->proFiles().first()->fileName());
        QList<QModelIndex> indexes = filters.at(i)->checkedIndexes();
        // for each variable in the project file
        for (int j=0; j<indexes.size(); ++j) {
            QModelIndex varindex = indexes.at(j);

            // for each value in the variable
            for (int k=m->rowCount(varindex) - 1; k>=0; --k) {
                QModelIndex valindex = m->index(k,0,varindex);
                ProItem *item = m->proItem(valindex);
                if (!item || item->kind() != ProItem::ValueKind)
                    continue;
                ProValue *val = static_cast<ProValue *>(item);
                QString absolutePathVal = QDir::toNativeSeparators(
                        profile.dir().absoluteFilePath(val->value()));
                if (m_filenames.contains(absolutePathVal)) {
                    m->removeItem(valindex);
                }
            }
        }
    }
}

void ScopeList::addFiles()
{
    QList<ProScopeFilter *> filters = m_models.values();
    foreach(ProScopeFilter *mf, filters) {
        ProEditorModel *m = qobject_cast<ProEditorModel*>(mf->sourceModel());
        if (!m)
            continue;

        QFileInfo profile(m->proFiles().first()->fileName());

        QList<QModelIndex> indexes = mf->checkedIndexes();
        for (int i=0; i<indexes.size(); ++i) {
            QModelIndex index = indexes.at(i);
            ProVariable *var = m->proVariable(index);
            if (!var)
                continue;
            QList<QFileInfo> files = m_files.values(var->variable());
            for (int j=0; j<files.size(); ++j) {
                QString val = profile.dir().relativeFilePath(files.at(j).absoluteFilePath());
                m->insertItem(new ProValue(val.toUtf8(), var), 0, index);
            }
        }
    }
}

ProScopeFilter *ScopeList::filter(ProEditorModel *model)
{
    if (!m_models.value(model)) {
        ProScopeFilter *filter = new ProScopeFilter(this);
        filter->setCheckable(ProScopeFilter::Variable);
        filter->setSourceModel(model);
        filter->setVariableFilter(m_files.keys());
        m_models[model] = filter;
    }

    return m_models.value(model);
}

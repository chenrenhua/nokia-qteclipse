/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

package com.trolltech.qtcppproject.pages.embedded;

import java.io.IOException;
import java.util.*;
import org.eclipse.swt.*;
import org.eclipse.swt.graphics.*;
import org.eclipse.swt.widgets.*;
import org.eclipse.swt.events.*;
import org.eclipse.core.runtime.FileLocator;
import org.eclipse.core.runtime.Platform;
import org.osgi.framework.Bundle;

public class ProEditorView extends Composite
{
    long handleWidget;
    ArrayList listeners;
    static Hashtable table = new Hashtable();
    static {
        try {
            System.loadLibrary ("qtcppproparser");
        } catch (UnsatisfiedLinkError ex) { ex.printStackTrace(); }
    }

    public ProEditorView(Composite parent, int style)
    {
        super (parent, style);
        handleWidget = createControl(handle, embeddedHandle);
        if (handleWidget == 0) SWT.error (SWT.ERROR_NO_HANDLES);
        table.put(new Long(handleWidget), this);
        
        setFont(getFont());
    
        listeners = new ArrayList();

        addDisposeListener(new DisposeListener() {
            public void widgetDisposed(DisposeEvent e) {
                ProEditorView.this.widgetDisposed(e);
            }
        });

        addControlListener(new ControlAdapter() {
            public void controlResized(ControlEvent e) {
                ProEditorView.this.controlResized(e);
            }
        });

    }

    public void widgetDisposed (DisposeEvent e)
    {
        table.remove(new Long(handleWidget));
        disposeControl(handleWidget);
        handleWidget = 0;
    }
  
    public void controlResized(ControlEvent e)
    {
        Rectangle rect = getClientArea();
        resizeControl(handleWidget, rect.x, rect.y, rect.width, rect.height);
    }

    public Point computeSize(int wHint, int hHint, boolean changed)
    {
        checkWidget();
        int [] result = new int[2];
        computeSize(handleWidget, result);
        if (wHint != SWT.DEFAULT) result[0] = wHint;
        if (hHint != SWT.DEFAULT) result[1] = hHint;
        int border = getBorderWidth();
        return new Point(result[0] + border * 2, result[1] + border * 2);
    }
    
    public void setFont(Font font)
    {
        super.setFont(font);
        
        if (font == null)
            return;
        FontData[] fntlist = font.getFontData();
        setFont (handleWidget, fntlist[0].getName(), fntlist[0].getHeight());
    }
    
    public void showModel(String fileName)
    {
        checkWidget();
        showModel(handleWidget, fileName);
    }

    public void reload()
    {
        checkWidget();
        reload(handleWidget);
    }

    public boolean save()
    {
        checkWidget();
        return save(handleWidget);
    }

    public boolean isDirty()
    {
        checkWidget();
        return isDirty(handleWidget);
    }

    public String contents()
    {
        checkWidget();
        return contents(handleWidget);
    }

    public boolean isActionEnabled(int id)
    {
        checkWidget();
        return isActionEnabled(handleWidget, id);
    }

    public void triggerAction(int id)
    {
        checkWidget();
        triggerAction(handleWidget, id);
    }

    public void addProEditorViewListener(ProEditorViewListener lstnr)
    {
        listeners.add(lstnr);
    }

    public void removeProEditorViewListener(ProEditorViewListener lstnr)
    {
        listeners.remove(listeners.indexOf(lstnr));
    }

    // native callback functions
    static void actionChanged(long handle, int id)
    {
        ProEditorView obj = (ProEditorView) table.get(new Long (handle));
        if (obj == null) return;
        for (int i=0; i<obj.listeners.size(); i++)
        {
            ((ProEditorViewListener)obj.listeners.get(i)).actionChanged(id);
        }
    }

    static void changed(long handle)
    {
        ProEditorView obj = (ProEditorView) table.get(new Long (handle));
        if (obj == null) return;
        for (int i=0; i<obj.listeners.size(); i++)
        {
            ((ProEditorViewListener)obj.listeners.get(i)).changed();
        }
    }

    static final native long createControl(long phandle, long socketWin);
    static final native void computeSize(long handle, int [] result);
    static final native void disposeControl(long handle);
    static final native void resizeControl(long handle, int x, int y, int width, int height);
    static final native void setFont(long handle, String family, int size);
    static final native void showModel(long handle, String fileName);
    static final native void reload(long handle);
    static final native boolean save(long handle);
    static final native boolean isDirty(long handle);
    static final native String contents(long handle);
    static final native boolean isActionEnabled(long handle, int id);
    static final native void triggerAction(long handle, int id);
}

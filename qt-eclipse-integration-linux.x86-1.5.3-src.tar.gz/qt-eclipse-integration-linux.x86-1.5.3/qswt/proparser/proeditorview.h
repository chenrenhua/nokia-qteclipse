/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

#ifndef PROEDITORVIEW_H
#define PROEDITORVIEW_H

#include <QtGui/QWidget>
#include <QtGui/QTreeView>
#include <QtGui/QCheckBox>

namespace Qt4ProjectManager {
namespace Internal {
    class ProEditorModel;
    class ProItemInfoManager;
    class ValueEditor;
} //namespace
} //namespace

QT_FORWARD_DECLARE_CLASS(ProFile)
class DetailsView;

class ProEditorView : public QWidget
{
    Q_OBJECT
    Q_CLASSINFO("ClassID", "{62D0CA85-68E7-40D8-B65A-455F232A2F54}")
    Q_CLASSINFO("InterfaceID", "{56398B5A-2395-4342-8B8E-05C70A5EEF70}")
    Q_CLASSINFO("EventsID", "{CF722267-3CEA-4CD2-99C9-27B98B0048D8}")
    Q_CLASSINFO("ToSuperClass", "QWidget")

public:
    ProEditorView(QWidget *parent = 0);
    ~ProEditorView();

    static Qt4ProjectManager::Internal::ProEditorModel *aquireModel(const QString &fileName);
    static void releaseModel(Qt4ProjectManager::Internal::ProEditorModel *editorModel);
    static void updateModel(Qt4ProjectManager::Internal::ProEditorModel *editorModel);

public slots:
    void showModel(const QString &fileName);
    void reload();
    bool save();

    bool isDirty() const;

    QString contents() const;

    bool isActionEnabled(int id);
    void triggerAction(int id);

signals:
    void actionChanged(int id);
    void changed();

private slots:
    void modelReset();
    void enableAdvanced(bool enabled);

private:
    void adaptPalette(QWidget *widget);
    static QMap<QString, Qt4ProjectManager::Internal::ProEditorModel *> &modelMap();
    static QMap<Qt4ProjectManager::Internal::ProEditorModel *, int> &modelRefCount();

    Qt4ProjectManager::Internal::ProItemInfoManager *m_infomanager;
    Qt4ProjectManager::Internal::ProEditorModel *m_model;

    QTreeView *m_explorerView;
    DetailsView *m_detailsView;
    Qt4ProjectManager::Internal::ValueEditor *m_valueView;

    QCheckBox *m_advanced;
};

#endif //PROEDITORVIEW_H

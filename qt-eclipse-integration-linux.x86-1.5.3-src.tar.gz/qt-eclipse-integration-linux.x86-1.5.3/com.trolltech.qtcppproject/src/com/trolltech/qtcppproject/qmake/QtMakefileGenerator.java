/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

package com.trolltech.qtcppproject.qmake;

import java.util.Map;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.OperationCanceledException;

public class QtMakefileGenerator extends IncrementalProjectBuilder
{
	protected IProject[] build(int kind, Map args, IProgressMonitor monitor) throws CoreException
	{
		if (kind != AUTO_BUILD) {		
 			runQMake(getProject(), monitor);
		}
		
		return null;
	}
	
	protected void clean(IProgressMonitor monitor) {
		// do nothing for now...
	}
 
 	public static String runQMake(IProject project, IProgressMonitor monitor)
	{
		checkCancel(monitor);
 		removeQMakeErrors(project);

		try {
 			String errStr = QMakeRunner.runQMake(project, null, monitor);
 			if (errStr != null) {
 				reportQMakeError(project, errStr);
 				return errStr;
			}
 		} catch (CoreException e) {
 			e.printStackTrace();
 			reportQMakeError(project, e.getLocalizedMessage());
 			return e.getLocalizedMessage();
		}
 		return null;
	}
	
 	public static void checkCancel(IProgressMonitor monitor) {
		if (monitor != null && monitor.isCanceled())
			throw new OperationCanceledException();
	}

 	private static final String QMAKE_PROBLEM = "com.trolltech.qtcppproject.qtproblem";

 	private static void removeQMakeErrors(IProject project) {
		try {
 			project.deleteMarkers(QMAKE_PROBLEM, false, IResource.DEPTH_ZERO);
		} catch (CoreException ex) {}
	}
	
 	private static void reportQMakeError(IProject project, String message) {
		try {
 			IMarker marker = project.createMarker(QMAKE_PROBLEM);
			marker.setAttribute(IMarker.MESSAGE, message);
			marker.setAttribute(IMarker.SEVERITY, IMarker.SEVERITY_ERROR);
		} catch (CoreException ex) {}		
	}
}


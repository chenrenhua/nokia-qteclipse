/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

package com.trolltech.qtcppproject.pages;

import java.io.File;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.ui.IEditorActionBarContributor;
import org.eclipse.ui.forms.IManagedForm;
import org.eclipse.ui.forms.editor.FormPage;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.part.FileEditorInput;

import com.trolltech.qtcppcommon.editors.EditorInputWatcher;
import com.trolltech.qtcppproject.editors.ProEditor;
import com.trolltech.qtcppproject.editors.ProEditorActionContributor;
import com.trolltech.qtcppproject.pages.embedded.ProEditorView;
import com.trolltech.qtcppproject.pages.embedded.ProEditorViewListener;

public class ProCommonPage extends FormPage implements SelectionListener,
	ProEditorViewListener
{
	private ProEditorView proEditorView = null;
	private ProEditor m_editor;
	
	public ProCommonPage(ProEditor editor)
	{
		super(editor, "com.trolltech.QtProEditor.pages.ProCommonPage", "Settings");
		m_editor = editor;
	}

	public void setActive(boolean active)
	{
		super.setActive(active);
	}
	
	public void widgetSelected(SelectionEvent e)
	{

	}
	
	public void widgetDefaultSelected(SelectionEvent e)
	{
		
	}
	
	public boolean isDirty()
	{
		return (proEditorView != null ? proEditorView.isDirty() : false);		
	}
	
	public void doSave(IProgressMonitor monitor)
	{
		if (proEditorView == null)
			return;
		FileEditorInput fin = (FileEditorInput)getEditorInput();
		if (!proEditorView.save()) {
    		MessageDialog.openError(getSite().getShell(),
    				"Error while saving file",
    				"Can't write to: " + fin.getFile().getLocation().toOSString()
    				+ "\nMake sure it's not write protected.");
		}
	}
	
	public boolean isActionEnabled(int actId) {
		return (proEditorView != null ? proEditorView.isActionEnabled(actId) : false);
	}
	
	public void triggerAction(int actId) {
		if (proEditorView == null)
			return;
		proEditorView.triggerAction(actId);
	}

	protected void createFormContent(IManagedForm managedForm)
	{
		Composite parent = managedForm.getForm().getBody();
		FormToolkit toolkit = managedForm.getToolkit();
		FileEditorInput fin = (FileEditorInput)getEditorInput();
		String fileName = fin.getFile().getLocation().toOSString();
		File file = new File(fileName);
		boolean readable = file.exists() && file.canRead();
		if (!readable) {
			EditorInputWatcher.createMissingFileInfo(parent, fileName);
			return;
		}
		GridLayout layout = new GridLayout(1, false);
		parent.setLayout(layout);
		createProEditorView(toolkit, parent);
		proEditorView.showModel(fileName);
	}

	private void createProEditorView(FormToolkit toolkit, Composite parent)
	{
		proEditorView = new ProEditorView(parent, SWT.EMBEDDED);
		proEditorView.addProEditorViewListener(this);
		proEditorView.setLayoutData(new GridData(600, 500));
		toolkit.adapt(proEditorView);
		toolkit.paintBordersFor(proEditorView);
	}

	public void reload() {
		proEditorView.reload();
	}

	public String contents() {
		return (proEditorView != null ? proEditorView.contents() : "");
	}

	public void changed() {
		m_editor.editorDirtyStateChanged();		
	}
	
	public void actionChanged(int id) {
		IEditorActionBarContributor cont = getEditorSite().getActionBarContributor();                
		if (cont instanceof ProEditorActionContributor) {
			ProEditorActionContributor pecont = (ProEditorActionContributor)cont;
			pecont.updateAction(id);
		}
	}

	public void setFocus() {
		super.setFocus();
		if (proEditorView != null)
			proEditorView.setFocus();
	}
}
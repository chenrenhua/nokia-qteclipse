/*********************************************************************************
**
** This file is part of Qt Eclipse Integration
**
** Copyright (c) 2009 Nokia Corporation and/or its subsidiary(-ies).
** All rights reserved.
**
** Contact:  Nokia Corporation (qt-info@nokia.com)
**
** Windows(R) users may use this file under the terms of the Qt Eclipse
** Plug In License Agreement Version 1.0 as attached in the LICENSE.TXT file.
**
** Linux(R) users may use this file under the terms of the GNU Lesser
** General Public License Agreement version 2.1 as shown in the LGPL-2_1.TXT file.
**
**********************************************************************************/

package com.trolltech.qtcppproject;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IConfigurationElement;
import org.eclipse.core.runtime.IExtension;
import org.eclipse.core.runtime.IExtensionPoint;
import org.eclipse.core.runtime.IExtensionRegistry;
import org.eclipse.core.runtime.ILog;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.ui.plugin.AbstractUIPlugin;
import org.osgi.framework.BundleContext;

import com.trolltech.qtcppproject.editors.ProPartitionScanner;
import com.trolltech.qtcppproject.preferences.PreferenceConstants;
import com.trolltech.qtcppproject.qmake.IQMakeEnvironmentModifier;

/**
 * The main plugin class to be used in the desktop.
 */
public class QtProjectPlugin extends AbstractUIPlugin {
	//The shared instance.
	private static QtProjectPlugin plugin;
	private ProPartitionScanner proPartScanner = null;
	private ProFileChangedListener proFileListener = new ProFileChangedListener();
	
	private static List<IQMakeEnvironmentModifier> envModifiers = null;

	public static final String TEMPLATE_LOCATION = "/com/trolltech/qtcppproject/wizards/templates/"; //$NON-NLS-1$
	
	public static final String PLUGIN_ID = "com.trolltech.qtcppproject"; //$NON-NLS-1$

	/**
	 * The constructor.
	 */
	public QtProjectPlugin() {
		super();
		plugin = this;
	}

	public void start(BundleContext context) throws Exception {
		super.start(context);
		ResourcesPlugin.getWorkspace().addResourceChangeListener(proFileListener);
	}

	/**
	 * This method is called when the plug-in is stopped
	 */
	public void stop(BundleContext context) throws Exception {
		super.stop(context);
		ResourcesPlugin.getWorkspace().removeResourceChangeListener(proFileListener);
		plugin = null;
		proPartScanner = null;
	}

	/**
	 * Returns the shared instance.
	 */
	public static QtProjectPlugin getDefault() {
		return plugin;
	}

	public ProPartitionScanner getProPartitionScanner()
	{
		if (proPartScanner == null)
			proPartScanner = new ProPartitionScanner();
		
		return proPartScanner;
	}
	
	/**
	 * Gets the default Qt version string
	 * @return the default Qt version string, or "" if none
	 */
	public String getDefaultQtVersion() {
		return QtProjectPlugin.getDefault().getPreferenceStore().getString(PreferenceConstants.QTVERSION_DEFAULT);
	}
	
	/**
	 * Adds a new Qt version and sets it as the default
	 * @param versionName Qt version name
	 * @param binDir Qt bin directory
	 * @param incDir Qt include directory
	 */
	public void addDefaultQtVersion(String versionName, IPath binDir, IPath incDir) {
		IPreferenceStore store = getPreferenceStore();

		int count = store.getInt(PreferenceConstants.QTVERSION_COUNT);
		store.setValue(PreferenceConstants.QTVERSION_COUNT, count + 1);
		
		store.setValue(PreferenceConstants.QTVERSION_NAME + "." + Integer.toString(count), versionName); //$NON-NLS-1$
		store.setValue(PreferenceConstants.QTVERSION_BINPATH + "." + Integer.toString(count), binDir.toOSString()); //$NON-NLS-1$
		store.setValue(PreferenceConstants.QTVERSION_INCLUDEPATH+ "." + Integer.toString(count), incDir.toOSString()); //$NON-NLS-1$

		store.setValue(PreferenceConstants.QTVERSION_DEFAULT, versionName);
	}

	/**
	 * Gets the list of registered qmake environment modifiers
	 * @return the list of modifiers, may be empty
	 */
	public List<IQMakeEnvironmentModifier> getEnvironmentModifierExtensions() {
		if (envModifiers == null) {
			envModifiers = new ArrayList<IQMakeEnvironmentModifier>();

			IExtensionRegistry extensionRegistry = Platform.getExtensionRegistry();
			IExtensionPoint extensionPoint = extensionRegistry.getExtensionPoint(PLUGIN_ID + ".qmakeEnvironmentModifier"); //$NON-NLS-1$
			IExtension[] extensions = extensionPoint.getExtensions();
			
			for (int i = 0; i < extensions.length; i++) {
				IExtension extension = extensions[i];
				IConfigurationElement[] elements = extension.getConfigurationElements();
				IConfigurationElement element = elements[0];
				
				boolean failed = false;
				try {
					Object extObject = element.createExecutableExtension("class"); //$NON-NLS-1$
					if (extObject instanceof IQMakeEnvironmentModifier) {
						envModifiers.add((IQMakeEnvironmentModifier)extObject);
					} else {
						failed = true;
					}
				} 
				catch (CoreException e) {
					failed = true;
				}
				
				if (failed) {
					logErrorMessage("Unable to load qmakeEnvironmentModifier extension from " + extension.getContributor().getName()); //$NON-NLS-1$
				}
			}
		}
		
		return envModifiers;
	}
	
	/**
	 * Logs the given error string to the error log
	 * @param errMsg the error message
	 */
	public void logErrorMessage(String errMsg) {
		ILog log = plugin.getLog();
		if (log != null) {
			log.log(new Status(IStatus.ERROR, PLUGIN_ID, errMsg));
		}
	}
}

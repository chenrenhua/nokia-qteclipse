#include "%INCLUDE%"

%CLASS%::%CLASS%(QWidget *parent)
    : %UI_CLASS%(parent)
{
	ui.setupUi(this);
}

%CLASS%::~%CLASS%()
{

}

#ifndef ADDDIALOG_H_
#define ADDDIALOG_H_

#include "ui_adddialog.h"

class AddDialog : public QDialog
{
	Q_OBJECT

public:
	AddDialog(QWidget *parent = 0);
	~AddDialog();

	QString name() { return ui.nameEdit->text(); }
	QString email() { return ui.emailEdit->text(); }
private:
    Ui::AddDialogClass ui;
};

#endif /*ADDDIALOG_H_*/
